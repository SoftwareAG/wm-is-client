

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import com.softwareag.util.IDataMap;
import com.wm.data.IData;
import com.wm.net.HttpHeader;
// --- <<IS-END-IMPORTS>> ---

public final class pub

{
	// ---( internal utility methods )---

	final static pub _instance = new pub();

	static pub _newInstance() { return new pub(); }

	static pub _cast(Object o) { return (pub)o; }

	// ---( server methods )---




	public static final void DataPump (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(DataPump)>> ---
		// @sigtype java 3.5
		long rowCount = 1;
		int chunkCount = 100;
		ServiceException se = null;
		
		System.err.println("Parsing request into IData structure->"+pipeline);
		IDataMap map = new IDataMap(pipeline);	
					
		try {
			rowCount = map.getAsLong("rowCount");
			chunkCount = map.getAsInteger("chunkCount");
		
			System.err.println("Start");
			final int theChunkCount = chunkCount;
			final long theRowCount = rowCount;
			System.err.println(String.format("Generating response with %s row(s).", rowCount) );
			System.err.println(String.format("Response stream will be flushed after each %s rows are written", chunkCount));
			System.err.println("(Increasing chunkCount will put more memory pressure on the server)");
			
			se = theCall(theRowCount, theChunkCount);
			
			if ( se == null ) {
				System.err.println("Done");
			}
			if ( se != null) {
				throw se;
			}
			
		} catch (Exception e) {
		
			System.err.println(String.format("Exception: %s", e.getMessage()));
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			System.err.println(sw.toString());
			Service.setResponse(String.format("{\"error\": \"%s\", \"details\":\"%s\"}",
					e.getMessage(), "Look in server log for more details").getBytes());
		}
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static ServiceException theCall(long theRowCount, int theChunkCount) {
	ServiceException se = null;
	
	final String row = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	
	System.err.println(theRowCount+" rowCount");
	System.err.println(theChunkCount+" chunkCount");
	File tempFile = new File( System.getProperty("java.io.tmpdir"), "DataPump.json");
	System.err.println(String.format("Writing data to %s", tempFile.getAbsolutePath()));
	
	try (FileOutputStream fos = new FileOutputStream(tempFile)) {
		fos.write( "{ \"rows\" : [\n".getBytes());
			    	
		for ( int idx=0; idx<theRowCount; idx++) {
			/*
			if ( idx%1000 == 0) {
				System.err.print('.');
			}
			*/
			
			fos.write(String.format("  { \"%s\": \"%s\" }", idx,row).getBytes() );		
			if ( idx+1 < theRowCount) {
				fos.write(",\n".getBytes());
			} else {
				fos.write("\n".getBytes());
			}
	
			
			if ( idx % theChunkCount == 0) {
				//System.err.print('+');
				fos.flush();					    											
			}					
		}
		fos.write( "  ]\n}\n".getBytes());
		System.err.println("Response file created");
					
	} catch (Exception e) {				
		System.err.println("err: "+e.getMessage());
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		se = new ServiceException( sw.toString() );
		se.printStackTrace(System.err);
			
	} 
	
	if ( se == null) {
		try {
			long fileSize = tempFile.length();
			HttpHeader hdr = Service.getHttpResponseHeader();
			if ( hdr != null ) { 
		    	//hdr.clearField("Content-Type");
		    	System.err.println("Setting Response Headers");
		    	System.err.println(String.format("File size: %s bytes",fileSize));
		    	hdr.addField("Content-Type", "application/json");
		    	//hdr.addField("Transfer-Encoding", "chunked");
		    	hdr.addField("Content-Length", Long.toString(fileSize));
			}
				    	
			FileInputStream fis = new FileInputStream( tempFile);
			Service.setResponse(fis);
			System.err.println("Response file input stream set on service response");
		} catch (Exception e) {
			
			System.err.println("err: "+e.getMessage());
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			se = new ServiceException( sw.toString() );
			se.printStackTrace(System.err);
		}
	}
	
	return se;
	}
	// --- <<IS-END-SHARED>> ---
}

